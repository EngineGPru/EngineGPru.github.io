﻿function isClient()
	return getLocalPlayer and true
end